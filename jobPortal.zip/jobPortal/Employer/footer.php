   <!-- Footer -->
    <div id="footer">
        <div id="top" class="noprint"><p><span class="noscreen">Back on top</span> <a href="#header" title="Back on top ^">^<span></span></a></p></div>
        <hr class="noscreen" />

        <p class="style1" id="createdby">Designer: Dhairya Chandra
          <!-- DON´T REMOVE, PLEASE! -->
        </p>
        <p id="copyright">&copy; 2018 - JOB RECRUITMENT</p>
  </div> <!-- /footer -->
